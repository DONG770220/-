import pygame.font
from pygame.sprite import Group
from ship import Ship  # 导入Ship类


class Scoreboard:
    """显示得分信息的类"""

    def __init__(self, ai_settings, screen, stats):
        """初始化显示得分涉及的属性"""
        self.screen = screen
        self.screen_rect = screen.get_rect()
        self.ai_settings = ai_settings
        self.stats = stats

        # 显示得分信息时使用的字体设置
        self.text_color = (255, 255, 255)  # 改为白色，在黑色背景上更明显
        self.font = pygame.font.SysFont(None, 36)  # 稍微减小字体大小

        # 准备所有图像
        self.prep_images()

    def prep_images(self):
        """准备所有需要显示的图像"""
        self.prep_score()
        self.prep_high_score()
        self.prep_level()
        self.prep_ships()
        self.prep_energy_bar()

    def prep_score(self):
        """将得分转换为一幅渲染的图像"""
        rounded_score = int(round(self.stats.score, -1))
        score_str = "Score: {:,}".format(rounded_score)
        self.score_image = self.font.render(score_str, True, self.text_color,
                                            self.ai_settings.bg_color)

        # 将得分放在屏幕左上角
        self.score_rect = self.score_image.get_rect()
        self.score_rect.left = 20
        self.score_rect.top = 20

    def prep_high_score(self):
        """将最高得分转换为渲染的图像"""
        high_score = int(round(self.stats.high_score, -1))
        high_score_str = "High Score: {:,}".format(high_score)
        self.high_score_image = self.font.render(high_score_str, True,
                                                 self.text_color, self.ai_settings.bg_color)

        # 将最高分放在屏幕顶部中央
        self.high_score_rect = self.high_score_image.get_rect()
        self.high_score_rect.centerx = self.screen_rect.centerx
        self.high_score_rect.top = self.score_rect.top

    def prep_level(self):
        """将等级转换为渲染的图像"""
        level_str = "Level: {}".format(self.stats.level)
        self.level_image = self.font.render(level_str, True,
                                            self.text_color, self.ai_settings.bg_color)

        # 将等级放在得分下方
        self.level_rect = self.level_image.get_rect()
        self.level_rect.left = self.score_rect.left
        self.level_rect.top = self.score_rect.bottom + 10

    def prep_ships(self):
        """显示还余下多少艘飞船"""
        self.ships = Group()
        for ship_number in range(self.stats.ships_left):
            ship = Ship(self.ai_settings, self.screen)
            # 缩小生命值指示器的大小
            ship.image = pygame.transform.scale(ship.image, (30, 30))
            ship.rect = ship.image.get_rect()
            ship.rect.x = 10 + ship_number * (ship.rect.width + 5)
            ship.rect.y = 10
            self.ships.add(ship)

    def prep_energy_bar(self):
        """准备能量条"""
        self.energy_bar_width = 200
        self.energy_bar_height = 20
        self.energy_bar_rect = pygame.Rect(
            self.screen_rect.right - self.energy_bar_width - 20,
            20,
            self.energy_bar_width,
            self.energy_bar_height
        )

    def check_high_score(self):
        """检查是否诞生了新的最高分"""
        if self.stats.score > self.stats.high_score:
            self.stats.high_score = self.stats.score
            self.prep_high_score()

    def show_energy_bar(self, ship):
        """显示能量条"""
        # 绘制背景
        pygame.draw.rect(self.screen, (50, 50, 50), self.energy_bar_rect)

        # 绘制能量填充
        energy_width = int(self.energy_bar_width * ship.get_energy_percent())
        if energy_width > 0:
            energy_rect = pygame.Rect(
                self.energy_bar_rect.left,
                self.energy_bar_rect.top,
                energy_width,
                self.energy_bar_height
            )
            # 根据能量值改变颜色
            if ship.get_energy_percent() > 0.3:
                color = (0, 255, 0)  # 绿色
            else:
                color = (255, 0, 0)  # 红色

            pygame.draw.rect(self.screen, color, energy_rect)

        # 绘制边框
        pygame.draw.rect(self.screen, (255, 255, 255), self.energy_bar_rect, 2)

        # 绘制能量文字
        energy_text = f"Energy: {int(ship.energy)}/{ship.max_energy}"
        energy_image = self.font.render(energy_text, True, self.text_color)
        energy_rect = energy_image.get_rect()
        energy_rect.right = self.energy_bar_rect.right
        energy_rect.top = self.energy_bar_rect.bottom + 5
        self.screen.blit(energy_image, energy_rect)

    def show_score(self, ship):
        """在屏幕上显示得分、等级和剩余飞船数"""
        self.screen.blit(self.score_image, self.score_rect)
        self.screen.blit(self.high_score_image, self.high_score_rect)
        self.screen.blit(self.level_image, self.level_rect)
        self.ships.draw(self.screen)
        # 显示能量条
        self.show_energy_bar(ship)