import pygame
import random


class Star:
    def __init__(self, screen_width, screen_height):
        self.x = random.randint(0, screen_width)
        self.y = random.randint(0, screen_height)
        self.size = random.randint(1, 3)
        self.speed = random.uniform(0.1, 0.5)
        self.brightness = random.randint(100, 255)
        self.screen_width = screen_width  # 保存屏幕宽度
        self.screen_height = screen_height  # 保存屏幕高度

    def update(self):
        self.y += self.speed
        if self.y > self.screen_height:
            self.y = 0
            self.x = random.randint(0, self.screen_width)  # 使用屏幕宽度

    def draw(self, screen):
        color = (self.brightness, self.brightness, self.brightness)
        pygame.draw.circle(screen, color, (int(self.x), int(self.y)), self.size)


class Background:
    def __init__(self, screen_width, screen_height):
        self.stars = []
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.create_stars(100)  # 创建100颗星星

    def create_stars(self, count):
        for _ in range(count):
            self.stars.append(Star(self.screen_width, self.screen_height))

    def update(self):
        for star in self.stars:
            star.update()

    def draw(self, screen):
        # 绘制深空背景
        screen.fill((10, 10, 40))
        # 绘制星星
        for star in self.stars:
            star.draw(screen)