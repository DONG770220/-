import json


class AchievementSystem:
    def __init__(self):
        self.achievements = {
            "first_blood": {"name": "第一滴血", "desc": "消灭第一个外星人", "unlocked": False, "shown": False},
            "survivor": {"name": "生存专家", "desc": "一命通关第一关", "unlocked": False, "shown": False},
            "sharpshooter": {"name": "神枪手", "desc": "连续命中10个外星人", "unlocked": False, "shown": False},
            "shield_master": {"name": "盾牌大师", "desc": "盾牌承受20次攻击", "unlocked": False, "shown": False},
            "combo_king": {"name": "连击之王", "desc": "达成10连击", "unlocked": False, "shown": False}
        }
        self.unlocked_achievements = []
        self.load_achievements()

    def load_achievements(self):
        """从文件加载成就"""
        try:
            with open('achievements.json', 'r') as f:
                data = json.load(f)
                for key in self.achievements:
                    if key in data:
                        self.achievements[key]["unlocked"] = data[key]
        except FileNotFoundError:
            pass

    def save_achievements(self):
        """保存成就到文件"""
        data = {key: self.achievements[key]["unlocked"] for key in self.achievements}
        with open('achievements.json', 'w') as f:
            json.dump(data, f)

    def unlock(self, achievement_id):
        """解锁成就"""
        if achievement_id in self.achievements and not self.achievements[achievement_id]["unlocked"]:
            self.achievements[achievement_id]["unlocked"] = True
            self.achievements[achievement_id]["shown"] = False
            self.unlocked_achievements.append(achievement_id)
            self.save_achievements()
            return True
        return False

    def get_recent_achievements(self):
        """获取最近解锁但未显示的成就"""
        recent = []
        for achievement_id in self.unlocked_achievements:
            if not self.achievements[achievement_id]["shown"]:
                recent.append(self.achievements[achievement_id])
                self.achievements[achievement_id]["shown"] = True
        self.unlocked_achievements = [a for a in self.unlocked_achievements
                                      if not self.achievements[a]["shown"]]
        return recent