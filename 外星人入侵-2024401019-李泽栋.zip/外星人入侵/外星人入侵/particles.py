import pygame
import random

class Particle:
    def __init__(self, x, y, color, velocity_range=(-2, 2), life=30):
        self.x = x
        self.y = y
        self.color = color
        self.vx = random.uniform(*velocity_range)
        self.vy = random.uniform(*velocity_range)
        self.life = life
        self.max_life = life
        self.size = random.randint(2, 5)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        self.vy += 0.1  # 重力效果

    def draw(self, screen):
        alpha = int(255 * (self.life / self.max_life))
        size = int(self.size * (self.life / self.max_life))
        if size > 0:
            surf = pygame.Surface((size*2, size*2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (*self.color, alpha), (size, size), size)
            screen.blit(surf, (int(self.x - size), int(self.y - size)))

    def is_dead(self):
        return self.life <= 0

class ParticleSystem:
    def __init__(self):
        self.particles = []

    def add_explosion(self, x, y, color=(255, 255, 0), count=20):
        for _ in range(count):
            self.particles.append(Particle(x, y, color))

    def update(self):
        self.particles = [p for p in self.particles if not p.is_dead()]
        for particle in self.particles:
            particle.update()

    def draw(self, screen):
        for particle in self.particles:
            particle.draw(screen)