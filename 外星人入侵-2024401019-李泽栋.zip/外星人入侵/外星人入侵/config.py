import json
from pathlib import Path


class Config:
    def __init__(self, config_file='config.json'):
        self.config_file = Path(config_file)
        self.default_config = {
            "graphics": {
                "screen_width": 1200,
                "screen_height": 800,
                "fullscreen": False
            },
            "audio": {
                "volume": 0.7,
                "mute": False
            },
            "gameplay": {
                "difficulty": "normal",
                "ship_speed": 0.8,
                "bullet_speed": 3
            }
        }
        self.load_config()

    def load_config(self):
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                self.data = {**self.default_config, **json.load(f)}
        else:
            self.data = self.default_config
            self.save_config()

    def save_config(self):
        with open(self.config_file, 'w') as f:
            json.dump(self.data, f, indent=2)

    def get(self, key, default=None):
        keys = key.split('.')
        value = self.data
        for k in keys:
            value = value.get(k, {})
        return value if value != {} else default

    def set(self, key, value):
        keys = key.split('.')
        data = self.data
        for k in keys[:-1]:
            data = data.setdefault(k, {})
        data[keys[-1]] = value
        self.save_config()