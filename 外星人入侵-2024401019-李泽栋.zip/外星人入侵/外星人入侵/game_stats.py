import json


class GameStats:
    """跟踪游戏的统计信息"""

    def __init__(self, ai_settings):
        """初始化统计信息"""
        self.ai_settings = ai_settings
        self.reset_stats()

        # 从文件读取最高分
        self.load_high_score()

        # 游戏刚启动时处于活动状态
        self.game_active = False

    def reset_stats(self):
        """初始化在游戏运行期间可能变化的统计信息"""
        self.ships_left = self.ai_settings.ship_limit
        self.score = 0
        self.level = 1

    def load_high_score(self):
        """从文件加载最高分"""
        try:
            with open('high_score.json', 'r') as f:
                data = json.load(f)
                self.high_score = data.get('high_score', 0)
        except (FileNotFoundError, json.JSONDecodeError):
            self.high_score = 0

    def save_high_score(self):
        """保存最高分到文件"""
        with open('high_score.json', 'w') as f:
            json.dump({'high_score': self.high_score}, f)