import pygame
from pygame.sprite import Sprite


class Ship(Sprite):
    def __init__(self, ai_settings, screen):
        super(Ship, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # 创建更精美的飞船图像
        self.image = pygame.Surface((60, 60), pygame.SRCALPHA)  # 添加透明通道

        # 绘制流线型飞船主体
        pygame.draw.polygon(self.image, (0, 200, 255), [
            (30, 0),  # 顶部
            (10, 20),  # 左翼前端
            (5, 50),  # 左翼后端
            (25, 55),  # 左引擎
            (35, 55),  # 右引擎
            (55, 50),  # 右翼后端
            (50, 20)  # 右翼前端
        ])

        # 添加飞船细节
        pygame.draw.polygon(self.image, (100, 230, 255), [
            (30, 5), (20, 25), (40, 25)
        ])  # 驾驶舱

        # 添加引擎光效
        pygame.draw.rect(self.image, (255, 100, 0), (22, 55, 5, 8))  # 左引擎光
        pygame.draw.rect(self.image, (255, 100, 0), (33, 55, 5, 8))  # 右引擎光

        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()

        # 将每艘新飞船放在屏幕底部中央
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom - 10

        # 在飞船的属性center中存储小数值
        self.center = float(self.rect.centerx)

        # 移动标志
        self.moving_right = False
        self.moving_left = False

        # 能量系统
        self.energy = 100
        self.max_energy = 100
        self.energy_regen_rate = 0.5
        self.special_attack_cost = 30

    def update(self):
        """根据移动标志调整飞船的位置"""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.center += self.ai_settings.ship_speed_factor
        if self.moving_left and self.rect.left > 0:
            self.center -= self.ai_settings.ship_speed_factor

        self.rect.centerx = self.center

        # 能量恢复
        if self.energy < self.max_energy:
            self.energy = min(self.max_energy, self.energy + self.energy_regen_rate)

    def blitme(self):
        """在指定位置绘制飞船"""
        self.screen.blit(self.image, self.rect)

    def center_ship(self):
        """让飞船在屏幕上居中"""
        self.center = self.screen_rect.centerx

    def use_special_attack(self):
        """使用特殊攻击"""
        if self.energy >= self.special_attack_cost:
            self.energy -= self.special_attack_cost
            return True
        return False

    def get_energy_percent(self):
        """获取能量百分比"""
        return self.energy / self.max_energy