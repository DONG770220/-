import pygame
from pygame.sprite import Group
import random

from settings import Settings
from ship import Ship
import game_functions as gf
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard
from particles import ParticleSystem
from background import Background
import os

# 设置环境变量来启用AVX2检测
os.environ['PYGAME_DETECT_AVX2'] = '1'


def run_game():
    ai_settings = Settings()
    pygame.init()

    # 性能优化设置
    screen = pygame.display.set_mode(
        (ai_settings.screen_width, ai_settings.screen_height),
        pygame.DOUBLEBUF | pygame.HWSURFACE
    )
    pygame.display.set_caption(ai_settings.caption)

    # 创建时钟对象控制帧率
    clock = pygame.time.Clock()

    # 创建星空背景
    background = Background(ai_settings.screen_width, ai_settings.screen_height)

    ship = Ship(ai_settings, screen)
    stats = GameStats(ai_settings)
    sb = Scoreboard(ai_settings, screen, stats)
    bullets = Group()
    alien_bullets = Group()
    aliens = Group()
    shields = Group()

    # 添加粒子系统
    particle_system = ParticleSystem()

    # 将粒子系统传递给相关函数
    gf.check_bullet_alien_collisions.particle_system = particle_system
    gf.ship_hit.particle_system = particle_system

    play_button = Button(screen, 'Play', centery=screen.get_rect().centery - 30)
    exit_button = Button(screen, 'Exit', centery=screen.get_rect().centery + 30)
    pause_button = Button(screen, 'Pause', centerx=screen.get_rect().right - 70,
                          centery=50, width=100, height=40, font_size=40)

    gf.set_english_mode()

    while True:
        # 控制帧率为60FPS
        clock.tick(60)

        gf.check_events(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, alien_bullets, shields,
                        exit_button, pause_button)
        if stats.game_active:
            ship.update()
            gf.update_bullets(ai_settings, screen, stats, sb, ship, aliens, bullets, alien_bullets, shields)
            gf.update_aliens(ai_settings, stats, sb, screen, ship, aliens, bullets, alien_bullets, shields)

            # 更新背景和粒子系统
            background.update()
            particle_system.update()

        gf.update_screen(ai_settings, screen, stats, sb, ship, aliens, bullets, alien_bullets, shields, play_button,
                         exit_button, pause_button, particle_system, background)


if __name__ == '__main__':
    run_game()