import json
import random


class Settings:
    def __init__(self):
        # 默认设置
        self.screen_width = 1200
        self.screen_height = 800
        self.bg_color = (10, 10, 40)  # 深蓝色星空背景
        self.caption = "Alien Invasion - Galactic Defense"

        # 飞船设置 - 提高移动速度！
        self.ship_speed_factor = 1.5  # 从 0.8 提高到 1.5，速度几乎翻倍！
        self.ship_limit = 3

        # 子弹设置
        self.bullet_speed_factor = 4  # 稍微提高子弹速度
        self.bullet_width = 8
        self.bullet_height = 20
        self.bullets_allowed = 8  # 增加允许的子弹数量

        # 外星人子弹设置
        self.alien_bullet_speed = 2.5
        self.alien_bullets_allowed = 8

        # 外星人设置
        self.alien_speed_factor = 0.6  # 稍微提高外星人速度以匹配新难度
        self.fleet_drop_speed = 10
        self.fleet_direction = 1  # 1表示向右，-1表示向左

        # 游戏节奏加快速度
        self.speedup_scale = 1.08  # 稍微提高速度增长
        # 分数提高速度
        self.score_scale = 1.5

        # 尝试加载设置，如果失败则使用默认值
        self.load_settings()

        self.initialize_dynamic_settings()

    def load_settings(self):
        """尝试从JSON文件加载设置"""
        try:
            with open('settings.json', 'r') as f:
                data = json.load(f)
                # 从JSON数据更新设置
                for key, value in data.items():
                    if hasattr(self, key):
                        setattr(self, key, value)
        except (FileNotFoundError, json.JSONDecodeError):
            # 如果文件不存在或格式错误，使用默认设置
            pass

    def initialize_dynamic_settings(self):
        """初始化随游戏进行而变化的设置"""
        self.ship_speed_factor = 1.5  # 与初始值保持一致
        self.bullet_speed_factor = 4
        self.alien_speed_factor = 0.6
        self.fleet_direction = 1
        self.alien_points = 50

        # 外星人射击频率（每帧的概率）
        self.alien_fire_chance = 0.001

    def increase_speed(self):
        """提高速度设置"""
        self.ship_speed_factor *= self.speedup_scale
        self.bullet_speed_factor *= self.speedup_scale
        self.alien_speed_factor *= self.speedup_scale
        self.alien_fire_chance *= 1.1  # 增加外星人射击频率