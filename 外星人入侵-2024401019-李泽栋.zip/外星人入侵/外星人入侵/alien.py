import pygame
from pygame.sprite import Sprite


class Alien(Sprite):
    """表示单个外星人的类"""

    def __init__(self, ai_settings, screen):
        """初始化外星人并设置其起始位置"""
        super(Alien, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # 创建更精美的外星人图像
        self.image = pygame.Surface((50, 50), pygame.SRCALPHA)  # 添加透明通道

        # 绘制外星人主体 - 飞碟形状
        pygame.draw.ellipse(self.image, (50, 200, 50), (5, 15, 40, 25))  # 飞碟底部
        pygame.draw.ellipse(self.image, (100, 255, 100), (10, 5, 30, 20))  # 飞碟顶部

        # 添加外星人细节
        pygame.draw.circle(self.image, (255, 50, 50), (18, 15), 4)  # 左眼
        pygame.draw.circle(self.image, (255, 50, 50), (32, 15), 4)  # 右眼
        pygame.draw.arc(self.image, (255, 100, 100), (20, 25, 10, 5), 0, 3.14, 2)  # 嘴巴

        # 添加发光效果
        pygame.draw.circle(self.image, (100, 255, 100, 100), (25, 25), 15, 2)

        self.rect = self.image.get_rect()

        # 每个外星人最初都在屏幕左上角附近
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        # 存储外星人的准确位置
        self.x = float(self.rect.x)

    def check_edges(self):
        """如果外星人位于屏幕边缘，就返回True"""
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right:
            return True
        elif self.rect.left <= 0:
            return True

    def update(self):
        """向左或向右移动外星人"""
        self.x += (self.ai_settings.alien_speed_factor *
                   self.ai_settings.fleet_direction)
        self.rect.x = self.x

    def blitme(self):
        """在指定位置绘制外星人"""
        self.screen.blit(self.image, self.rect)