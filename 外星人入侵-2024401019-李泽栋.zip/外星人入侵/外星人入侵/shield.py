import pygame
from pygame.sprite import Sprite


class Shield(Sprite):
    """保护飞船的盾牌"""

    def __init__(self, ai_settings, screen):
        super(Shield, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # 创建更精美的盾牌
        self.image = pygame.Surface((120, 40), pygame.SRCALPHA)  # 添加透明通道

        # 绘制能量盾牌
        self.draw_shield(3)  # 初始满生命值

        self.rect = self.image.get_rect()

        # 盾牌生命值
        self.health = 3

    def draw_shield(self, health):
        """根据生命值绘制盾牌"""
        self.image.fill((0, 0, 0, 0))  # 清空图像

        if health == 3:
            # 满生命值 - 蓝色能量盾
            pygame.draw.ellipse(self.image, (0, 150, 255, 180), (0, 0, 120, 40))
            pygame.draw.ellipse(self.image, (100, 200, 255, 120), (10, 10, 100, 20))
            pygame.draw.ellipse(self.image, (200, 230, 255, 80), (20, 15, 80, 10))
        elif health == 2:
            # 中等生命值 - 黄色能量盾
            pygame.draw.ellipse(self.image, (255, 200, 0, 180), (0, 0, 120, 40))
            pygame.draw.ellipse(self.image, (255, 230, 100, 120), (10, 10, 100, 20))
            pygame.draw.ellipse(self.image, (255, 245, 150, 80), (20, 15, 80, 10))
        elif health == 1:
            # 低生命值 - 红色能量盾
            pygame.draw.ellipse(self.image, (255, 50, 0, 180), (0, 0, 120, 40))
            pygame.draw.ellipse(self.image, (255, 100, 50, 120), (10, 10, 100, 20))
            pygame.draw.ellipse(self.image, (255, 150, 100, 80), (20, 15, 80, 10))

    def update(self):
        """更新盾牌状态"""
        self.draw_shield(self.health)

    def hit(self):
        """盾牌被击中"""
        self.health -= 1
        if self.health <= 0:
            self.kill()  # 盾牌被摧毁
        else:
            self.update()  # 更新盾牌外观

    def blitme(self):
        """绘制盾牌"""
        self.screen.blit(self.image, self.rect)