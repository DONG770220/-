import pygame
from pygame.sprite import Sprite


class AlienBullet(Sprite):
    """外星人发射的子弹类"""

    def __init__(self, ai_settings, screen, alien):
        """在外星人位置创建一个子弹对象"""
        super(AlienBullet, self).__init__()
        self.screen = screen

        # 创建更精美的外星人子弹
        self.image = pygame.Surface((8, 20), pygame.SRCALPHA)  # 添加透明通道

        # 绘制等离子子弹
        pygame.draw.rect(self.image, (255, 50, 50), (2, 0, 4, 18))  # 等离子核心
        pygame.draw.rect(self.image, (255, 150, 150), (1, 16, 6, 4))  # 等离子尾部
        pygame.draw.rect(self.image, (255, 200, 200), (3, 18, 2, 2))  # 高光

        self.rect = self.image.get_rect()
        self.rect.centerx = alien.rect.centerx
        self.rect.top = alien.rect.bottom

        # 存储用小数表示的子弹位置
        self.y = float(self.rect.y)

        self.speed_factor = ai_settings.alien_bullet_speed

    def update(self):
        """向下移动子弹"""
        self.y += self.speed_factor
        self.rect.y = self.y

    def draw_bullet(self):
        """在屏幕上绘制子弹"""
        self.screen.blit(self.image, self.rect)